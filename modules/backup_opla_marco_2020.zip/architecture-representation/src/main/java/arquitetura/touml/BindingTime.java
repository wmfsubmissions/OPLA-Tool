package arquitetura.touml;

/**
 * @author edipofederle<edipofederle@gmail.com>
 */
public class BindingTime {

    public static String DESIGN_TIME = "DESIGN_TIME";
    public static String LINK_TIME = "LINK_TIME";
    public static String COMPILE_TIME = "COMPILE_TIME";
    public static String RUN_TIME = "RUN_TIME";

}
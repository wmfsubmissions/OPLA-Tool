package arquitetura.touml;

/**
 * @author edipofederle<edipofederle@gmail.com>
 */
public interface Transformation {
    void useTransformation();
}
package arquitetura.representation;

public class ArchitectureHolder {


    private static String name;

    public static String getName() {
        return name;
    }

    public static void setName(String n) {
        name = n;
    }

}

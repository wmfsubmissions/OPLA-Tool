package arquitetura.exceptions;

public class CustonTypeNotFound extends Exception {

    private static final long serialVersionUID = -3442722843370279067L;

    public CustonTypeNotFound(String message) {
        super(message);
    }

}

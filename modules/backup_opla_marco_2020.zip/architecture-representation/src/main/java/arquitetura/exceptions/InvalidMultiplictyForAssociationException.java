package arquitetura.exceptions;

public class InvalidMultiplictyForAssociationException extends Exception {

    /**
     *
     */
    private static final long serialVersionUID = 1043777522910793420L;

    public InvalidMultiplictyForAssociationException(String message) {
        super(message);
    }

}

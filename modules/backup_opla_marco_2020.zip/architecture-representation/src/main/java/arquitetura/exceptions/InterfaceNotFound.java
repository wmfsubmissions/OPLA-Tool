package arquitetura.exceptions;

public class InterfaceNotFound extends Exception {

    private static final long serialVersionUID = -2374348175818258051L;

    public InterfaceNotFound(String message) {
        super(message);
    }

}

package arquitetura.exceptions;

/**
 * @author edipofederle
 */
public class SMartyProfileNotAppliedToModelExcepetion extends Exception {

    private static final long serialVersionUID = -4015737605013782452L;

    public SMartyProfileNotAppliedToModelExcepetion(String message) {
        super(message);
    }

}

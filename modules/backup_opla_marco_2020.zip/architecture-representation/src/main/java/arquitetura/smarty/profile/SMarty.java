package arquitetura.smarty.profile;

import arquitetura.exceptions.ModelNotFoundException;

/**
 * @author edipofederle<edipofederle@gmail.com>
 */
public class SMarty {

    public static void main(String[] args) throws ModelNotFoundException {
        new ProfileSMarty("smarty.profile");
    }

}
